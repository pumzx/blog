package com.panzx.issea.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.Data;

import static com.panzx.issea.service.Constants.*;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
@Data
public class GeoJsonGeometries {

    private List<Point> pointsList;
    private List<Line> linesList;
    private List<Polygon> polygonsList;

    GeoJsonGeometries(JSONObject geoJson) {
        this.pointsList = new ArrayList<>(1024);
        this.linesList = new ArrayList<>(1024);
        this.polygonsList = new ArrayList<>(1024);

        this.loadGeneric(geoJson, new Object());
    }

    private void loadGeneric(JSONObject geoJson, Object properties) {

        String type = String.valueOf(geoJson.get("type"));
        if (Objects.nonNull(this.pointsList)) {
            switch (type) {
                case POINT: {
                    JSONArray coordinates = geoJson.getJSONArray("coordinates");
                    this.loadPoint(coordinates, properties);
                    return;
                }
                case MULTI_POINT: {
                    JSONArray coordinates = geoJson.getJSONArray("coordinates");
                    coordinates.forEach(coordinate -> this.loadPoint((JSONArray) coordinate, properties));
                    return;
                }
                default: break;
            }
        }
        if (Objects.nonNull(this.linesList)) {
            switch (type) {
                case LINE_STRING: {
                    JSONArray coordinates = geoJson.getJSONArray("coordinates");
                    this.loadLine(coordinates, properties);
                    return;
                }
                case MULTI_LINE_STRING: {
                    JSONArray coordinates = geoJson.getJSONArray("coordinates");
                    coordinates.forEach(coordinate -> this.loadLine((JSONArray) coordinate, properties));
                    return;
                }
                default: break;
            }
        }
        if (Objects.nonNull(this.polygonsList)) {
            switch (type) {
                case POLYGON: {
                    JSONArray coordinates = geoJson.getJSONArray("coordinates");
                    this.loadPolygon(coordinates, properties);
                    return;
                }
                case MULTI_POLYGON: {
                    JSONArray coordinates = geoJson.getJSONArray("coordinates");
                    coordinates.forEach(coordinate -> this.loadPolygon((JSONArray) coordinate, properties));
                    return;
                }
                default: break;
            }
        }
        switch (type) {
            case FEATURE: {
                JSONObject jsonObject = geoJson.getJSONObject("geometry");
                this.loadGeneric(jsonObject, properties);
                return;
            }
            case FEATURE_COLLECTION: {
                JSONArray features = geoJson.getJSONArray("features");
                for (Object feature : features) {
                    JSONObject jsonObject = (JSONObject) feature;
                    JSONObject geometry = jsonObject.getJSONObject("geometry");
                    this.loadGeneric(geometry, properties);
                }
                return;
            }
            case GEOMETRY_COLLECTION: {
                JSONArray geometries = geoJson.getJSONArray("geometries");
                for (Object geometry : geometries) {
                    JSONObject jsonObject = (JSONObject) geometry;
                    this.loadGeneric(jsonObject, properties);
                }
                return;
            }
            default: break;
        }
    }

    private void loadPoint(JSONArray coordinates, Object properties) {
        this.pointsList.add(new Point(FEATURE, new Geometry(POINT, coordinates), properties));
    }

    private void loadLine(JSONArray coordinates, Object properties) {
        this.linesList.add(new Line(FEATURE, new Geometry(LINE_STRING, coordinates), properties));
    }

    private void loadPolygon(JSONArray coordinates, Object properties) {
        this.polygonsList.add(new Polygon(FEATURE, new Geometry(POLYGON, coordinates), properties));
    }
}
