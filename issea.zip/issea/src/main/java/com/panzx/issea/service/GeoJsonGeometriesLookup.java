package com.panzx.issea.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import static com.panzx.issea.service.Constants.*;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
public class GeoJsonGeometriesLookup {

    private List<Dim> D;

    GeoJsonGeometriesLookup(JSONObject geoJson) {
        GeoJsonGeometries extracted = new GeoJsonGeometries(geoJson);

        this.D = new ArrayList<>(3);

        this.D.add(new Dim(extracted.getPointsList(), new ArrayList<>(), null));
        this.D.add(new Dim(extracted.getLinesList(), new ArrayList<>(), null));
        this.D.add(new Dim(extracted.getPolygonsList(), new ArrayList<>(), null));

        for (int d = 0; d < 3; d++) {
            Dim dim = this.D.get(d);
            if (dim.getGeoms().size() > 0) {
                Lookup lookup = Lookup.getInstance();
                dim.setLookup(lookup);
                lookup.rbush(0, false);

                List geoms = dim.getGeoms();
                List<TreeNode> bboxs = dim.getBboxs();
                //Lookup lookup = dim.getLookup();

                for (int i = 0, len = geoms.size(); i < len; i++) {
                    TreeNode bbox = tbbox(JSONObject.parseObject(JSON.toJSONString(geoms.get(i))));
                    bbox.setId(i);
                    bboxs.add(i, bbox);
                }
                lookup.load(bboxs);
            }
        }
    }



    private TreeNode tbbox(JSONObject geojson) {
        double[] bbox = new double[]{
                (double) Integer.MAX_VALUE,
                (double) Integer.MAX_VALUE,
                (double) Integer.MIN_VALUE,
                (double) Integer.MIN_VALUE
        };

        coordEach(geojson, bbox);
        return new TreeNode(0, bbox[2], bbox[3], bbox[0], bbox[1]);
    }

    private void coordEach(JSONObject geojson, double[] bbox) {
        if (Objects.isNull(geojson)) {
            return;
        }
        int featureIndex, geometryIndex, j, k, l, stopG, wrapShrink = 0, coordIndex = 0;
        List<List> coords;
        Geometry geometry;
        boolean isGeometryCollection, excludeWrapCoord = false;
        String type = geojson.getString("type");
        boolean isFeatureCollection = FEATURE_COLLECTION.equals(type),
                isFeature = FEATURE.equals(type);
        int stop = isFeatureCollection ? geojson.getJSONArray("features").size() : 1;
        JSONObject geometryMaybeCollection;


        for (featureIndex = 0; featureIndex < stop; featureIndex++) {
            //geometryMaybeCollection = (isFeatureCollection ? geojson.getJSONArray("features").get(featureIndex).geometry :
            //        (isFeature ? geojson.geometry : geojson));
            geometryMaybeCollection = isFeature ? geojson.getJSONObject("geometry") : geojson;
            isGeometryCollection = (Objects.nonNull(geometryMaybeCollection)) ? GEOMETRY_COLLECTION.equals(geometryMaybeCollection.getString("type")) : false;
            stopG = isGeometryCollection ? geometryMaybeCollection.getJSONArray("geometries").size() : 1;

            for (geometryIndex = 0; geometryIndex < stopG; geometryIndex++) {
                int featureSubIndex = 0;
                geometry = isGeometryCollection ?
                        (Geometry) geometryMaybeCollection.getJSONArray("geometries").get(geometryIndex)
                        : JSONObject.parseObject(JSON.toJSONString(geometryMaybeCollection), Geometry.class);

                // Handles null Geometry -- Skips this geometry
                if (geometry == null) {
                    continue;
                }
                coords = geometry.getCoordinates();
                String geomType = geometry.getType();

                wrapShrink = (excludeWrapCoord && (POLYGON.equals(geomType) || MULTI_POLYGON.equals(geomType))) ? 1 : 0;

                if (StringUtils.isEmpty(geomType)) {
                    continue;
                }
                switch (geomType) {
                    case POINT:
                        List list = coords.get(0);
                        double[] coord = new double[] {(double) list.get(0), (double) list.get(1)};
                        compareBbox(bbox, coord);
                        coordIndex++;
                        featureSubIndex++;
                        break;
//                    case LINE_STRING:
//                    case MULTI_POINT:
//                        for (j = 0; j < coords.size(); j++) {
//                            callback(coords.get(j), coordIndex, featureIndex, featureSubIndex);
//                            coordIndex++;
//                            if (MULTI_POINT.equals(geomType)) {
//                                featureSubIndex++;
//                            }
//                        }
//                        if (LINE_STRING.equals(geomType)) {
//                            featureSubIndex++;
//                        }
//                        break;
                    case POLYGON:
                    case MULTI_LINE_STRING:
                        for (j = 0; j < coords.size(); j++) {
                            for (k = 0; k < coords.get(j).size() - wrapShrink; k++) {
                                List p = (List) coords.get(j).get(k);
                                double[] coord2 = new double[]{Double.valueOf(String.valueOf(p.get(0))),
                                        Double.valueOf(String.valueOf(p.get(1)))};
                                compareBbox(bbox, coord2);
                                coordIndex++;
                            }
                            if (MULTI_LINE_STRING.equals(geomType)) {
                                featureSubIndex++;
                            }
                        }
                        if (POLYGON.equals(geomType)) {
                            featureSubIndex++;
                        }
                        break;
//                    case MULTI_POLYGON:
//                        for (j = 0; j < coords.size(); j++) {
//                            for (k = 0; k < coords[j].length; k++)
//                                for (l = 0; l < coords[j][k].length - wrapShrink; l++) {
//                                    callback(coords[j][k][l], coordIndex, featureIndex, featureSubIndex);
//                                    coordIndex++;
//                                }
//                            featureSubIndex++;
//                        }
//                        break;
//                    case GEOMETRY_COLLECTION:
//                        for (j = 0; j < geometry.geometries.length; j++)
//                            coordEach(geometry.geometries[j], callback, excludeWrapCoord);
//                        break;
                    default:
                        throw new RuntimeException("Unknown Geometry Type");
                }
            }
        }

    }

    private void compareBbox(double[] bbox, double[] coord) {
        if (bbox[0] > coord[0]) {bbox[0] = coord[0];}
        if (bbox[1] > coord[1]) {bbox[1] = coord[1];}
        if (bbox[2] < coord[0]) {bbox[2] = coord[0];}
        if (bbox[3] < coord[1]) {bbox[3] = coord[1];}
    }

    public boolean hasContainers(Geometry geometry) {
        Options options = new Options();
        options.setLimit(1);
        return 1 == forEachCotainer(geometry, options);
    }

    private int forEachCotainer(Geometry geometry, Options options) {
        int count = 0;
        int size = getGeometryDimension(geometry);
        Boolean[] ignores = new Boolean[]{false, false, false};

        for (int d = size; d < 3; d++) {
            if (ignores[d]) {
                continue;
            }

            Dim dim = this.D.get(d);
            if (Objects.isNull(dim.getLookup())) {
                continue;
            }

            TreeNode bbox = tbbox(JSONObject.parseObject(JSON.toJSONString(geometry)));

            List<TreeNode> bboxs = dim.getLookup().search(bbox);

            for (int i = 0, len = bboxs.size(); i < len; i++) {
                AbstractEntry geom = (AbstractEntry) dim.getGeoms().get(bboxs.get(i).getId());
                if (!tcontains(geom.getGeometry(), geometry)) {
                    continue;
                }
                //func(geom, count);
                count++;
                if (options.getLimit() > 0 && options.getLimit() == count) {
                    return count;
                }
            }
        }
        return count;
    }

    private boolean tcontains(Geometry feature1, Geometry feature2) {
        String type1 = feature1.getType();
        String type2 = feature2.getType();
        Geometry geom1 = feature1;
        Geometry geom2 = feature2;
        List<Double> coords1 = feature1.getCoordinates();
        List<Double> coords2 = feature2.getCoordinates();

        switch (type1) {
            case POINT:
                switch (type2) {
                    case POINT:
                        return compareCoords(coords1, coords2);
                    default:
                        throw new RuntimeException("feature2 " + type2 + " geometry not supported");
                }
//            case MULTI_POINT:
//                switch (type2) {
//                    case POINT:
//                        return isPointInMultiPoint(geom1, geom2);
//                    case MULTI_POINT:
//                        return isMultiPointInMultiPoint(geom1, geom2);
//                    default:
//                        throw new RuntimeException("feature2 " + type2 + " geometry not supported");
//                }
//            case LINE_STRING:
//                switch (type2) {
//                    case POINT:
//                        return isPointOnLine(geom2, geom1, {ignoreEndVertices: true});
//                    case LINE_STRING:
//                        return isLineOnLine(geom1, geom2);
//                    case MULTI_POINT:
//                        return isMultiPointOnLine(geom1, geom2);
//                    default:
//                        throw new RuntimeException("feature2 " + type2 + " geometry not supported");
//                }
            case POLYGON:
                switch (type2) {
                    case POINT:
                        return booleanPointInPolygon(geom2, geom1, true);
//                    case LINE_STRING:
//                        return isLineInPoly(geom1, geom2);
//                    case POLYGON:
//                        return isPolyInPoly(geom1, geom2);
//                    case MULTI_POINT:
//                        return isMultiPointInPoly(geom1, geom2);
                    default:
                        throw new RuntimeException("feature2 " + type2 + " geometry not supported");
                }
            default:
                throw new RuntimeException("feature1 " + type1 + " geometry not supported");
        }

        //return false;
    }

    private boolean compareCoords(List<Double> pair1, List<Double> pair2) {
        return pair1.get(0) == pair2.get(0) && pair1.get(1) == pair2.get(1);
    }

    private int getGeometryDimension(Geometry geometry) {
        switch (geometry.getType()) {
            case POINT: return 0;
            case LINE_STRING: return 1;
            case POLYGON: return 2;
            default: throw new RuntimeException("Unsupported GeoJSON type. Use one of: Point, LineString, Polygon");
        }
    }

    private boolean booleanPointInPolygon(Geometry point, Geometry polygon, boolean ignoreBoundary) {
        Assert.notNull(point, "point is null");
        Assert.notNull(polygon, "point is null");

        List<Double> pt = point.getCoordinates();
        List<List> polys = polygon.getCoordinates();
        String type = polygon.getType();
        //var bbox = polygon.bbox;

        // Quick elimination if point is not inside bbox
        //if (bbox && inBBox(pt, bbox) === false) return false;

        // normalize to multipolygon
        if (POLYGON.equals(type)) polys = polys;

        boolean insidePoly = false;
        for (int i = 0; i < polys.size() && !insidePoly; i++) {
            // check if it is in the outer ring first
            if (inRing(pt, polys.get(i).get(0), ignoreBoundary)) {
                boolean inHole = false;
                int k = 1;
                // check for the point in any of the holes
                while (k < polys.get(i).size() && !inHole) {
                    if (inRing(pt, polys.get(i).get(k), !ignoreBoundary)) {
                        inHole = true;
                    }
                    k++;
                }
                if (!inHole) insidePoly = true;
            }
        }
        return insidePoly;
    }

    private boolean inRing(List<Double> pt, Object o, boolean ignoreBoundary) {
        boolean isInside = false;
        List<List<Double>> ring = (List<List<Double>>) o;
        if (ring.get(0).get(0) == ring.get(ring.size() - 1).get(0) &&
                ring.get(0).get(1) == ring.get(ring.size() - 1).get(1)) {
            ring = ring.subList(0, ring.size() - 1);
        }

        for (int i = 0, j = ring.size() - 1; i < ring.size(); j = i++) {
            double xi = ring.get(i).get(0), yi = ring.get(i).get(1);
            double xj = ring.get(j).get(0), yj = ring.get(j).get(1);
            boolean onBoundary = (pt.get(1) * (xi - xj) + yi * (xj - pt.get(0)) + yj * (pt.get(0) - xi) == 0) &&
                    ((xi - pt.get(0)) * (xj - pt.get(0)) <= 0) && ((yi - pt.get(1)) * (yj - pt.get(1)) <= 0);
            if (onBoundary) return !ignoreBoundary;
            boolean intersect = ((yi > pt.get(1)) != (yj > pt.get(1))) &&
                    (pt.get(0) < (xj - xi) * (pt.get(1) - yi) / (yj - yi) + xi);
            if (intersect) isInside = !isInside;
        }
        return isInside;
    }
}
