package com.panzx.issea.service;

import lombok.Data;

import java.util.List;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
@Data
public class Geometry {
    private String type;
    private List coordinates;

    public Geometry(String type, List coordinates) {
        this.type = type;
        this.coordinates = coordinates;
    }
}
