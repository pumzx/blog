package com.panzx.issea.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author panzhixiong
 * @date 2019/11/24
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreeNode {
    private List<TreeNode> children;
    private Integer height;
    private Boolean leaf;
    private Integer id;
    private double maxX;
    private double maxY;
    private double minX;
    private double minY;

    public TreeNode(int id, double maxX, double maxY, double minX, double minY) {
        this.id = id;
        this.maxX = maxX;
        this.maxY = maxY;
        this.minX = minX;
        this.minY = minY;
    }

    public TreeNode(List<TreeNode> children, int height, boolean leaf,
                    double maxX, double maxY, double minX, double minY) {
        this.children = children;
        this.height = height;
        this.leaf = leaf;
        this.maxX = maxX;
        this.maxY = maxY;
        this.minX = minX;
        this.minY = minY;
    }


}
