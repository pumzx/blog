package com.panzx.issea.service;

import lombok.Data;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
@Data
public class Polygon extends AbstractEntry {

    public Polygon(String type, Geometry geometry, Object properties) {
        super(type, geometry, properties);
    }
}
