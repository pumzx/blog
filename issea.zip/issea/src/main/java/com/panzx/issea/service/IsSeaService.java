package com.panzx.issea.service;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
public class IsSeaService {

    private GeoJsonGeometriesLookup lookup = null;
    public boolean isSea(double lat, double lon) throws IOException {

        if (Objects.isNull(lookup)) {
            // 加载json文件
            JSONObject geoJson = getJSONObjectFromLocalFile();
            this.lookup = new GeoJsonGeometriesLookup(geoJson);
        }

        List<Double> latLon = new ArrayList<>(2);
        latLon.add(lat);
        latLon.add(lon);
        Geometry geometry = new Geometry("Point", latLon);

        return lookup.hasContainers(geometry);
    }

    private JSONObject getJSONObjectFromLocalFile() throws IOException {
        String path = this.getClass().getClassLoader().getResource("earth-seas-10km.geo.json").toString();
        path = path.replace("\\", "/");
        if (path.contains(":")) {
            path = path.replace("file:", "");
        }
        String input = FileUtils.readFileToString(new File(path), "UTF-8");
        JSONObject jsonObject = JSONObject.parseObject(input);
        return jsonObject;
    }
}
