package com.panzx.issea.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;
import org.springframework.util.comparator.Comparators;

import java.util.*;

/**
 * @author panzhixiong
 * @date 2019/11/24
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Lookup {
    private static Lookup lookup = new Lookup();

    private TreeNode data;
    private int maxEntries;
    private int minEntries;

    public void load(List<TreeNode> bboxs) {
        if (CollectionUtils.isEmpty(bboxs)) {
            return;
        }

        if (bboxs.size() < this.minEntries) {
            for (int i = 0; i < bboxs.size(); i++) {
                this.insert(bboxs.get(i));
            }
            return;
        }

        TreeNode node = this.build(bboxs, 0, bboxs.size() - 1, 0);

        if (0 == this.data.getChildren().size()) {
            // save as is if tree is empty
            this.data = node;

        } else if (this.data.getHeight() == node.getHeight()) {
            // split root if trees have the same height
            this._splitRoot(this.data, node);

        } else {
            if (this.data.getHeight() < node.getHeight()) {
                // swap trees if inserted one is bigger
                TreeNode tmpNode = this.data;
                this.data = node;
                node = tmpNode;
            }

            // insert the small tree into the large tree at appropriate level
            this._insert(node, this.data.getHeight() - node.getHeight() - 1, true);
        }

    }

    private void insert(TreeNode item) {
        if (Objects.nonNull(item)) this._insert(item, this.data.getHeight() - 1, false);
    }

    private void _insert(TreeNode item, int level, boolean isNode) {

        Object toBBox = new Object();
        TreeNode bbox = isNode ? item : toBBox(item);
        List<TreeNode> insertPath = new ArrayList<>();

        // find the best node for accommodating the item, saving all nodes along the path too
        TreeNode node = this._chooseSubtree(bbox, this.data, level, insertPath);

        // put the item into the node
        node.getChildren().add(item);
        extend(node, bbox);

        // split on node overflow; propagate upwards if necessary
        while (level >= 0) {
            if (insertPath.get(level).getChildren().size() > this.maxEntries) {
                this._split(insertPath, level);
                level--;
            } else break;
        }

        // adjust bboxes along the insertion path
        this._adjustParentBBoxes(bbox, insertPath, level);
    }

    private void _adjustParentBBoxes(TreeNode bbox, List<TreeNode> path, int level) {
        // adjust bboxes along the given tree path
        for (int i = level; i >= 0; i--) {
            extend(path.get(i), bbox);
        }
    }

    private void _split(List<TreeNode> insertPath, int level) {
        TreeNode node = insertPath.get(level);
        int M = node.getChildren().size(), m = this.minEntries;

        this._chooseSplitAxis(node, m, M);

        int splitIndex = this._chooseSplitIndex(node, m, M);

        TreeNode newNode = createTreeNode(node.getChildren().subList(splitIndex, node.getChildren().size() - splitIndex));
        newNode.setHeight(node.getHeight());
        newNode.setLeaf(node.getLeaf());

        calcBBox(node, new Object());
        calcBBox(newNode, new Object());

        if (0 != level) insertPath.get(level - 1).getChildren().add(newNode);
        else this._splitRoot(node, newNode);
    }

    private int _chooseSplitIndex(TreeNode node, int m, int M) {
        int i,  overlap, area, minOverlap, minArea, index = 0;
        TreeNode bbox1, bbox2;
        minOverlap = minArea = Integer.MAX_VALUE;

        for (i = m; i <= M - m; i++) {
            bbox1 = distBBox(node, 0, i, new Object(), null);
            bbox2 = distBBox(node, i, M, new Object(), null);

            overlap = intersectionArea(bbox1, bbox2);
            area = bboxArea(bbox1) + bboxArea(bbox2);

            // choose distribution with minimum overlap
            if (overlap < minOverlap) {
                minOverlap = overlap;
                index = i;

                minArea = area < minArea ? area : minArea;

            } else if (overlap == minOverlap) {
                // otherwise choose distribution with minimum area
                if (area < minArea) {
                    minArea = area;
                    index = i;
                }
            }
        }

        return index;
    }

    private void _chooseSplitAxis(TreeNode node, int m, int M) {

//        String compareMinX = node.getLeaf() ? this.compareMinX : compareNodeMinX,
//                compareMinY = node.getLeaf() ? this.compareMinY : compareNodeMinY;
                int xMargin = this._allDistMargin(node, m, M, (Comparator<TreeNode>) (o1, o2) -> compareNodeMinX(o1, o2));
                int yMargin = this._allDistMargin(node, m, M, (Comparator<TreeNode>) (o1, o2) -> compareNodeMinY(o1, o2));

        // if total distributions margin value is minimal for x, sort by minX,
        // otherwise it's already sorted by minY
        if (xMargin < yMargin) {
            node.getChildren().sort((o1, o2) -> compareNodeMinX(o1, o2));
        } else {
            node.getChildren().sort((o1, o2) -> compareNodeMinY(o1, o2));
        }
    }

    private int _allDistMargin(TreeNode node, int m, int M, Comparator compare) {

        node.getChildren().sort(compare);

        Object toBBox = new Object();
        TreeNode leftBBox = distBBox(node, 0, m, toBBox, null),
                rightBBox = distBBox(node, M - m, M, toBBox, null);
        int margin = bboxMargin(leftBBox) + bboxMargin(rightBBox);
        int i;
        TreeNode child;

        for (i = m; i < M - m; i++) {
            child = node.getChildren().get(i);
            extend(leftBBox, node.getLeaf() ? toBBox(child) : child);
            margin += bboxMargin(leftBBox);
        }

        for (i = M - m - 1; i >= m; i--) {
            child = node.getChildren().get(i);
            extend(rightBBox, node.getLeaf() ? toBBox(child) : child);
            margin += bboxMargin(rightBBox);
        }

        return margin;
    }


    private void _splitRoot(TreeNode node, TreeNode newNode) {
        List<TreeNode> treeNodes = Arrays.asList(node, newNode);
        this.data = createTreeNode(treeNodes);
        this.data.setHeight(node.getHeight() + 1);
        this.data.setLeaf(false);
        calcBBox(this.data, new Object());
    }

    private TreeNode _chooseSubtree(TreeNode bbox, TreeNode node, int level, List path) {

        int i, len, area, enlargement, minArea, minEnlargement;
        TreeNode child, targetNode = null;

        while (true) {
            path.add(node);

            if (node.getLeaf() || path.size() - 1 == level) break;

            minArea = minEnlargement = Integer.MAX_VALUE;

            for (i = 0, len = node.getChildren().size(); i < len; i++) {
                child = node.getChildren().get(i);
                area = bboxArea(child);
                enlargement = enlargedArea(bbox, child) - area;

                // choose entry with the least area enlargement
                if (enlargement < minEnlargement) {
                    minEnlargement = enlargement;
                    minArea = area < minArea ? area : minArea;
                    targetNode = child;

                } else if (enlargement == minEnlargement) {
                    // otherwise choose one with the smallest area
                    if (area < minArea) {
                        minArea = area;
                        targetNode = child;
                    }
                }
            }

            node = Objects.isNull(targetNode) ? node.getChildren().get(0) : targetNode;
        }

        return node;
    }

    private int enlargedArea(TreeNode a, TreeNode b) {
        return Double.valueOf((Math.max(b.getMaxX(), a.getMaxX()) - Math.min(b.getMinX(), a.getMinX())) *
                (Math.max(b.getMaxY(), a.getMaxY()) - Math.min(b.getMinY(), a.getMinY()))).intValue();
    }

    private int bboxArea(TreeNode a) {
        return Double.valueOf((a.getMaxX() - a.getMinX()) * (a.getMaxY() - a.getMinY())).intValue();
    }

    private int bboxMargin(TreeNode a) {
        return Double.valueOf((a.getMaxX() - a.getMinX()) + (a.getMaxY() - a.getMinY())).intValue();
    }


    private int compareNodeMinX(TreeNode a, TreeNode b) { return Double.valueOf(a.getMinX() - b.getMinX()).intValue(); }
    private int compareNodeMinY(TreeNode a, TreeNode b) { return Double.valueOf(a.getMinY() - b.getMinY()).intValue(); }

    private int intersectionArea(TreeNode a, TreeNode b) {
        double minX = Math.max(a.getMinX(), b.getMinX()),
                minY = Math.max(a.getMinY(), b.getMinY()),
                maxX = Math.min(a.getMaxX(), b.getMaxX()),
                maxY = Math.min(a.getMaxY(), b.getMaxY());

        return Double.valueOf(Math.max(0, maxX - minX) *
                Math.max(0, maxY - minY)).intValue();
    }

    private TreeNode build(List<TreeNode> items, int left, int right, int height) {
        int N = right - left + 1, M = this.maxEntries;
        TreeNode node;

        if (N <= M) {
            // reached leaf level; return leaf
            node = createTreeNode(items.subList(left, right + 1));
            calcBBox(node, items);
            return node;
        }

        if (0 == height) {
            // target height of the bulk-loaded tree
            height = Double.valueOf(Math.ceil(Math.log(N) / Math.log(M))).intValue();

            // target number of root entries to maximize storage utilization
            M = Double.valueOf(Math.ceil(N / Math.pow(M, height - 1))).intValue();
        }
        
        node = createTreeNode(new ArrayList<>());
        node.setLeaf(false);
        node.setHeight(height);

        // split the items into M mostly square tiles

        int N2 = Double.valueOf(Math.ceil(N / M)).intValue(),
                N1 = Double.valueOf(N2 * Math.ceil(Math.sqrt(M))).intValue(),
                i, j, right2, right3;


        multiSelect(items, left, right, N1, "minX");

        for (i = left; i <= right; i += N1) {

            right2 = Math.min(i + N1 - 1, right);

            multiSelect(items, i, right2, N2, "minY");

            for (j = i; j <= right2; j += N2) {

                right3 = Math.min(j + N2 - 1, right2);

                // pack each entry recursively
                node.getChildren().add(this.build(items, j, right3, height - 1));
            }
        }

        calcBBox(node, items);

        return node;
    }

    private TreeNode createNode(List<TreeNode> list, boolean leafNode) {
        TreeNode node = new TreeNode();
        node.setChildren(new ArrayList<>(list.size()));
        node.setHeight(1);
        node.setLeaf(true);
        for (TreeNode bbox : list) {
            TreeNode tmp = new TreeNode(null, 0, true,
                    (double) Integer.MAX_VALUE,
                    (double) Integer.MAX_VALUE,
                    (double) Integer.MIN_VALUE,
                    (double) Integer.MIN_VALUE);
            node.getChildren().add(tmp);
        }

        return node;
    }

    private void calcBBox(TreeNode node, Object toBBox) {
        distBBox(node, 0, node.getChildren().size(), toBBox, node);
    }

    private TreeNode distBBox(TreeNode node, int k, int p, Object toBBox, TreeNode destNode) {
        if (Objects.isNull(destNode))  {
            destNode = createTreeNode(null);
        }
        destNode.setMinX(Integer.MAX_VALUE);
        destNode.setMinY(Integer.MAX_VALUE);
        destNode.setMaxX(Integer.MIN_VALUE);
        destNode.setMaxY(Integer.MIN_VALUE);

        TreeNode child;
        for (int i = k; i < p; i++) {
            child = node.getChildren().get(i);
            extend(destNode, node.getLeaf() ? toBBox(child) : child);
        }

        return destNode;
    }

    private void extend(TreeNode a, TreeNode b) {
        a.setMinX(Math.min(a.getMinX(), b.getMinX()));
        a.setMinY(Math.min(a.getMinY(), b.getMinY()));
        a.setMaxX(Math.max(a.getMaxX(), b.getMaxX()));
        a.setMaxY(Math.max(a.getMaxY(), b.getMaxY()));
    }

    private TreeNode toBBox(TreeNode items) {
        return items;
    }

    private void multiSelect(List<TreeNode> arr, int left, int right, int n, String compareField) {
        Stack<Integer> stack = new Stack<>();
        stack.push(left);
        stack.push(right);
        int mid;

        while (stack.size() > 0) {
            right = stack.pop();
            left = stack.pop();

            if (right - left <= n) continue;

            mid = left + Double.valueOf(Math.ceil((double)(right - left) / n / 2) * n).intValue();
            quickselect(arr, mid, left, right, compareField);

            stack.push(left);
            stack.push(mid);
            stack.push(mid);
            stack.push(right);
        }

    }

    private void quickselect(List<TreeNode> arr, int k, int left, int right, String compareField) {
        left = left | 0;
        right = right | (arr.size() - 1);
        //compare = compare || defaultCompare;

        while (right > left) {
            if (right - left > 600) {
                int n = right - left + 1;
                int m = k - left + 1;
                int z = Double.valueOf(Math.log(n)).intValue();
                int s = Double.valueOf(0.5 * Math.exp(2 * z / 3)).intValue();
                int sd = Double.valueOf(0.5 * Math.sqrt(z * s * (n - s) / n) * (m - n / 2 < 0 ? -1 : 1)).intValue();
                int newLeft = Double.valueOf(Math.max(left, Math.floor(k - m * s / n + sd))).intValue();
                int newRight = Double.valueOf(Math.min(right, Math.floor(k + (n - m) * s / n + sd))).intValue();
                quickselect(arr, k, newLeft, newRight, compareField);
            }

            TreeNode t = arr.get(k);
            int i = left;
            int j = right;

            swap(arr, left, k);
            if (compare(arr.get(right), t, compareField) > 0) swap(arr, left, right);

            while (i < j) {
                swap(arr, i, j);
                i++;
                j--;
                while (compare(arr.get(i), t, compareField) < 0) i++;
                while (compare(arr.get(j), t, compareField) > 0) j--;
            }

            if (compare(arr.get(left), t, compareField) == 0) swap(arr, left, j);
            else {
                j++;
                swap(arr, j, right);
            }

            if (j <= k) left = j + 1;
            if (k <= j) right = j - 1;
        }
    }

    private int compare(TreeNode a, TreeNode b, String compareField) {
        if ("minX".equals(compareField)) {
            return compareMinX(a, b);
        }
        if ("minY".equals(compareField)) {
            return compareMinY(a, b);
        }
        return 0;
    }

    private int compareMinX(TreeNode a, TreeNode b) {
        return Double.valueOf(a.getMinX() - b.getMinX()).intValue();
    }
    private int compareMinY(TreeNode a, TreeNode b) {
        return Double.valueOf(a.getMinY() - b.getMinY()).intValue();
    }

    private void swap(List<TreeNode> arr, int i, int j) {
        TreeNode tmp = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, tmp);
    }

    public static Lookup getInstance() {
        return lookup;
    }

    public void rbush(int maxEntries, boolean format) {
        this.maxEntries = Math.max(4, maxEntries | 9);
        this.minEntries = (int) Math.max(2, Math.ceil(this.maxEntries * 0.4));

        if (format) {
            //this._initFormat(format);
        }

        this.clear();
    }

    private void clear() {
        this.data = createTreeNode(new ArrayList<>());
    }

    private TreeNode createTreeNode(List<TreeNode> children) {
        return new TreeNode(
                children,
                1,
                true,
                (double) Integer.MIN_VALUE,
                (double) Integer.MIN_VALUE,
                (double) Integer.MAX_VALUE,
                (double) Integer.MAX_VALUE
        );
    }

    private TreeNode createBboxNode(int id) {
        return new TreeNode(
                id,
                (double) Integer.MAX_VALUE,
                (double) Integer.MAX_VALUE,
                (double) Integer.MIN_VALUE,
                (double) Integer.MIN_VALUE
        );
    }

    public List<TreeNode> search(TreeNode bbox) {
        TreeNode node = this.data;
        Stack<TreeNode> result = new Stack<>();
        //toBBox = this.toBBox;

        if (!intersects(bbox, node)) return Collections.EMPTY_LIST;

        Stack<TreeNode> nodesToSearch = new Stack<>();
        int i, len;
        TreeNode child, childBBox;

        while (Objects.nonNull(node)) {
            for (i = 0, len = node.getChildren().size(); i < len; i++) {

                child = node.getChildren().get(i);
                childBBox = node.getLeaf() ? toBBox(child) : child;

                if (intersects(bbox, childBBox)) {
                    if (node.getLeaf()) result.push(child);
                    else if (contains(bbox, childBBox)) this.all(child, result);
                    else nodesToSearch.push(child);
                }
            }
            node = nodesToSearch.pop();
        }

        return result;
    }

    private void all(TreeNode node, Stack<TreeNode> result) {
        Stack<TreeNode> nodesToSearch = new Stack<>();
        while (Objects.nonNull(node)) {
            if (node.getLeaf()) {
                for (TreeNode treeData : node.getChildren()) {
                    result.push(treeData);
                }

            }
            else {
                for (TreeNode treeData : node.getChildren()) {
                    nodesToSearch.push(treeData);
                }
            }

            node = nodesToSearch.pop();
        }
    }

    private boolean intersects(TreeNode a, TreeNode b) {
        return  b.getMinX() <= a.getMaxX() &&
                b.getMinY() <= a.getMaxY() &&
                b.getMaxX() >= a.getMinX() &&
                b.getMaxY() >= a.getMinY();
    }

    private boolean contains(TreeNode a, TreeNode b) {
        return  a.getMinX() <= b.getMinX() &&
                a.getMinY() <= b.getMinY() &&
                b.getMaxX() <= a.getMaxX() &&
                b.getMaxY() <= a.getMaxY();
    }

}
