package com.panzx.issea;

import com.panzx.issea.service.IsSeaService;

import java.io.IOException;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
public class Sea {
    public static void main(String[] args) {
        IsSeaService isSeaService = new IsSeaService();
        boolean result = false;
        try {
            result = isSeaService.isSea(113, 29);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(result);
    }
}
