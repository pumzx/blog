package com.panzx.issea.service;

import lombok.Data;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
@Data
public class AbstractEntry {
    private String type;
    private Geometry geometry;
    private Object properties;

    public AbstractEntry(String type, Geometry geometry, Object properties) {
        this.type = type;
        this.geometry = geometry;
        this.properties = properties;
    }
}
