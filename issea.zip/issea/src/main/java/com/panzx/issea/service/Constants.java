package com.panzx.issea.service;

/**
 * @author panzhixiong
 * @date 2019/11/23
 */
public class Constants {

    public static final String POINT = "Point";
    public static final String MULTI_POINT = "MultiPoint";
    public static final String LINE_STRING = "LineString";
    public static final String MULTI_LINE_STRING = "MultiLineString";
    public static final String POLYGON = "Polygon";
    public static final String MULTI_POLYGON = "MultiPolygon";
    public static final String FEATURE = "Feature";
    public static final String FEATURE_COLLECTION = "FeatureCollection";
    public static final String GEOMETRY_COLLECTION = "GeometryCollection";
}
