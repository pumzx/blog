package com.panzx.issea.service;

import lombok.Data;

/**
 * @author panzhixiong
 * @date 2019/11/24
 */
@Data
public class Options {
    private int limit;
}
