package com.panzx.issea.service;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @author panzhixiong
 * @date 2019/11/24
 */
@Data
@AllArgsConstructor
public class Dim {
    private List geoms;
    private List<TreeNode> bboxs;
    private Lookup lookup;
}
